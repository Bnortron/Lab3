public class BuddyInfo
{
    private static String name;
    private static String address;
    private static int phoneNumber;

    public static String getName() {
        return name;
    }

    public static String getAddress() {
        return address;
    }

    public static int getPhoneNumber() {
        return phoneNumber;
    }

    public static void main(String[] args)
    {
        BuddyInfo buddyInfo = new BuddyInfo();

        buddyInfo.name = "homer";

        System.out.println("Hello " + buddyInfo.getName());
    }
}